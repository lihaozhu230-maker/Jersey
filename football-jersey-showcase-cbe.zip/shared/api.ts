/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Jersey type for the football jersey showcase
 * Supports both image URLs and uploaded video/image files
 */
export interface Jersey {
  id: string;
  name: string;
  team: string;
  price: number;
  media: string; // Base64 or image URL
  mediaType: "image" | "video"; // Type of media
  fileName?: string; // Original filename for uploaded files
  createdAt: string;
}

/**
 * Request body for creating a new jersey
 */
export interface CreateJerseyRequest {
  name: string;
  team: string;
  price: number;
  media: string; // Base64 or image URL
  mediaType: "image" | "video";
  fileName?: string;
}

/**
 * Request body for updating jersey price
 */
export interface UpdateJerseyPriceRequest {
  price: number;
}
