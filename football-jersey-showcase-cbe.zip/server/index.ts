import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  getJerseys,
  createJersey,
  updateJerseyPrice,
  deleteJersey,
} from "./routes/jerseys";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Jersey API routes
  app.get("/api/jerseys", getJerseys);
  app.post("/api/jerseys", createJersey);
  app.put("/api/jerseys/:id", updateJerseyPrice);
  app.delete("/api/jerseys/:id", deleteJersey);

  return app;
}
