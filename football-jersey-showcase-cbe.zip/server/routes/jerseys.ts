import { RequestHandler } from "express";
import { z } from "zod";

// In-memory storage (in production, use a real database)
let jerseys: Array<{
  id: string;
  name: string;
  team: string;
  price: number;
  media: string;
  mediaType: "image" | "video";
  fileName?: string;
  createdAt: string;
}> = [
  {
    id: "1",
    name: "Classic Blue Jersey",
    team: "Manchester United",
    price: 89.99,
    media: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=500&fit=crop",
    mediaType: "image",
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    name: "Red & White Striped",
    team: "Liverpool",
    price: 79.99,
    media: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop",
    mediaType: "image",
    createdAt: new Date().toISOString(),
  },
  {
    id: "3",
    name: "Golden Legacy",
    team: "Arsenal",
    price: 84.99,
    media: "https://images.unsplash.com/photo-1516478179778-b1f6f62db81f?w=400&h=500&fit=crop",
    mediaType: "image",
    createdAt: new Date().toISOString(),
  },
];

const createJerseySchema = z.object({
  name: z.string().min(1, "Jersey name is required"),
  team: z.string().min(1, "Team name is required"),
  price: z.number().positive("Price must be positive"),
  media: z.string().min(1, "Media is required"),
  mediaType: z.enum(["image", "video"]),
  fileName: z.string().optional(),
});

const updatePriceSchema = z.object({
  price: z.number().positive("Price must be positive"),
});

export const getJerseys: RequestHandler = (_req, res) => {
  res.json(jerseys);
};

export const createJersey: RequestHandler = (req, res) => {
  try {
    const data = createJerseySchema.parse(req.body);
    const newJersey: typeof jerseys[0] = {
      id: Date.now().toString(),
      name: data.name,
      team: data.team,
      price: data.price,
      media: data.media,
      mediaType: data.mediaType,
      fileName: data.fileName,
      createdAt: new Date().toISOString(),
    };
    jerseys.push(newJersey);
    res.status(201).json(newJersey);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: error.errors });
    } else {
      res.status(500).json({ error: "Failed to create jersey" });
    }
  }
};

export const updateJerseyPrice: RequestHandler = (req, res) => {
  try {
    const { id } = req.params;
    const data = updatePriceSchema.parse(req.body);

    const jersey = jerseys.find((j) => j.id === id);
    if (!jersey) {
      res.status(404).json({ error: "Jersey not found" });
      return;
    }

    jersey.price = data.price;
    res.json(jersey);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: error.errors });
    } else {
      res.status(500).json({ error: "Failed to update jersey" });
    }
  }
};

export const deleteJersey: RequestHandler = (req, res) => {
  const { id } = req.params;
  const index = jerseys.findIndex((j) => j.id === id);

  if (index === -1) {
    res.status(404).json({ error: "Jersey not found" });
    return;
  }

  const deleted = jerseys.splice(index, 1);
  res.json(deleted[0]);
};
