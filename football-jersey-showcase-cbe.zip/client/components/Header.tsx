import { useState } from "react";
import { Shirt, LogOut, User } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { LoginDialog } from "@/components/LoginDialog";

export function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const [loginDialogOpen, setLoginDialogOpen] = useState(false);

  const handleLogout = () => {
    logout();
  };

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-accent">
              <Shirt className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-0.5">
              <h1 className="text-xl font-black text-foreground tracking-tight">
                JERSEY
              </h1>
              <p className="text-xs font-semibold text-primary uppercase tracking-widest">
                Showcase
              </p>
            </div>
          </div>

          {/* Title */}
          <div className="hidden sm:block text-center flex-1">
            <p className="text-sm font-semibold text-muted-foreground">
              Premium Football Jerseys
            </p>
          </div>

          {/* Auth Section */}
          <div className="flex items-center gap-3">
            {isAuthenticated && user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20">
                  <User className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-primary">
                    {user.name}
                  </span>
                </div>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="gap-2 rounded-lg"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">Logout</span>
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => setLoginDialogOpen(true)}
                size="sm"
                className="gap-2 rounded-lg font-semibold"
              >
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Sign In</span>
              </Button>
            )}
          </div>
        </div>
      </header>

      <LoginDialog
        open={loginDialogOpen}
        onOpenChange={setLoginDialogOpen}
      />
    </>
  );
}
