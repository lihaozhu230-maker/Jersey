import { useState, useRef } from "react";
import { CreateJerseyRequest } from "@shared/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Plus, Loader2, Upload, X } from "lucide-react";
import { toast } from "sonner";
import { LoginDialog } from "@/components/LoginDialog";

interface UploadJerseyDialogProps {
  onAdd: (jersey: CreateJerseyRequest) => Promise<void>;
}

export function UploadJerseyDialog({ onAdd }: UploadJerseyDialogProps) {
  const { isAuthenticated } = useAuth();
  const [open, setOpen] = useState(false);
  const [loginDialogOpen, setLoginDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadMode, setUploadMode] = useState<"url" | "file">("file");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string>("");
  const [isDragging, setIsDragging] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    team: "",
    price: "",
    imageUrl: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const processFile = (file: File) => {
    // Validate file type - only images for this optimization
    const validImageTypes = ["image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml"];
    const validVideoTypes = ["video/mp4", "video/webm", "video/quicktime"];
    const allValidTypes = [...validImageTypes, ...validVideoTypes];

    if (!allValidTypes.includes(file.type)) {
      toast.error("Only images (JPG, PNG, GIF, WebP, SVG) and videos (MP4, WebM, MOV) are supported");
      return;
    }

    // Validate file size
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
      toast.error(`File too large. Maximum size: 50MB (${(file.size / 1024 / 1024).toFixed(2)}MB selected)`);
      return;
    }

    setSelectedFile(file);

    // Auto-fill name from filename if empty
    if (!formData.name.trim()) {
      const nameFromFile = file.name.split('.')[0].replace(/[-_]/g, ' ');
      setFormData(prev => ({
        ...prev,
        name: nameFromFile.charAt(0).toUpperCase() + nameFromFile.slice(1)
      }));
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setFilePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleClearFile = () => {
    setSelectedFile(null);
    setFilePreview("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.name.trim()) {
      toast.error("Jersey name is required");
      return;
    }
    if (!formData.team.trim()) {
      toast.error("Team name is required");
      return;
    }
    if (!formData.price || parseFloat(formData.price) <= 0) {
      toast.error("Price must be greater than 0");
      return;
    }

    let media: string;
    let mediaType: "image" | "video";
    let fileName: string | undefined;

    if (uploadMode === "file") {
      if (!selectedFile) {
        toast.error("Please select a file");
        return;
      }
      media = filePreview;
      mediaType = selectedFile.type.startsWith("video/") ? "video" : "image";
      fileName = selectedFile.name;
    } else {
      if (!formData.imageUrl.trim()) {
        toast.error("Image URL is required");
        return;
      }
      media = formData.imageUrl;
      mediaType = "image";
    }

    setIsLoading(true);
    try {
      await onAdd({
        name: formData.name,
        team: formData.team,
        price: parseFloat(formData.price),
        media,
        mediaType,
        fileName,
      });

      setFormData({ name: "", team: "", price: "", imageUrl: "" });
      handleClearFile();
      setUploadMode("file");
      setOpen(false);
      toast.success("Jersey added successfully!");
    } catch (error) {
      toast.error("Failed to add jersey");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDialogOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      // Reset form when closing
      handleClearFile();
      setFormData({ name: "", team: "", price: "", imageUrl: "" });
      setUploadMode("file");
    }
    setOpen(newOpen);
  };

  return (
    <>
      <Button
        onClick={() => {
          if (!isAuthenticated) {
            setLoginDialogOpen(true);
          } else {
            setOpen(true);
          }
        }}
        size="lg"
        className="gap-2 rounded-lg font-semibold shadow-lg hover:shadow-xl transition-shadow"
      >
        <Plus className="w-5 h-5" />
        Add New Jersey
      </Button>

      <LoginDialog
        open={loginDialogOpen}
        onOpenChange={setLoginDialogOpen}
        onLoginSuccess={() => setOpen(true)}
      />

      <Dialog open={open} onOpenChange={handleDialogOpenChange}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Jersey</DialogTitle>
            <DialogDescription>
              Upload a new football jersey. Choose between URL or local file upload.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Jersey Name</Label>
              <Input
                id="name"
                name="name"
                placeholder="e.g., Classic Blue Jersey"
                value={formData.name}
                onChange={handleInputChange}
                disabled={isLoading}
                className="rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="team">Team Name</Label>
              <Input
                id="team"
                name="team"
                placeholder="e.g., Manchester United"
                value={formData.team}
                onChange={handleInputChange}
                disabled={isLoading}
                className="rounded-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Price ($)</Label>
              <Input
                id="price"
                name="price"
                type="number"
                step="0.01"
                min="0"
                placeholder="89.99"
                value={formData.price}
                onChange={handleInputChange}
                disabled={isLoading}
                className="rounded-lg"
              />
            </div>

            {/* Upload Mode Toggle */}
            <div className="space-y-2">
              <Label>Media Upload</Label>
              <div className="flex gap-2 rounded-lg border border-border overflow-hidden">
                <button
                  type="button"
                  onClick={() => {
                    setUploadMode("url");
                    handleClearFile();
                  }}
                  disabled={isLoading}
                  className={`flex-1 py-2 px-3 text-sm font-medium transition-colors ${
                    uploadMode === "url"
                      ? "bg-primary text-primary-foreground"
                      : "bg-background text-foreground hover:bg-muted"
                  }`}
                >
                  URL
                </button>
                <button
                  type="button"
                  onClick={() => setUploadMode("file")}
                  disabled={isLoading}
                  className={`flex-1 py-2 px-3 text-sm font-medium transition-colors ${
                    uploadMode === "file"
                      ? "bg-primary text-primary-foreground"
                      : "bg-background text-foreground hover:bg-muted"
                  }`}
                >
                  Local File
                </button>
              </div>
            </div>

            {/* URL Input */}
            {uploadMode === "url" && (
              <div className="space-y-2">
                <Label htmlFor="imageUrl">Image URL</Label>
                <Input
                  id="imageUrl"
                  name="imageUrl"
                  type="url"
                  placeholder="https://example.com/jersey.jpg"
                  value={formData.imageUrl}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  className="rounded-lg"
                />
                <p className="text-xs text-muted-foreground">
                  Use a direct image URL (supports HTTPS). Consider using Unsplash
                  or similar services for free images.
                </p>
              </div>
            )}

            {/* File Upload Input */}
            {uploadMode === "file" && (
              <div className="space-y-3">
                <Label htmlFor="file">Upload Image or Video</Label>
                <input
                  ref={fileInputRef}
                  id="file"
                  type="file"
                  accept="image/jpeg,image/png,image/gif,image/webp,image/svg+xml,video/mp4,video/webm,video/quicktime"
                  onChange={handleFileSelect}
                  disabled={isLoading || selectedFile !== null}
                  className="hidden"
                />

                {/* Drag and Drop Zone */}
                {!selectedFile && (
                  <div
                    ref={dropZoneRef}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`relative w-full py-8 border-2 border-dashed rounded-xl transition-all duration-200 cursor-pointer flex flex-col items-center justify-center gap-3 ${
                      isDragging
                        ? "border-primary bg-primary/5 scale-105"
                        : "border-border hover:border-primary/50 hover:bg-primary/2.5"
                    } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    <div className={`p-3 rounded-lg transition-colors ${isDragging ? "bg-primary/20" : "bg-primary/10"}`}>
                      <Upload className={`w-6 h-6 ${isDragging ? "text-primary animate-bounce" : "text-primary/60"}`} />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-semibold text-foreground">
                        {isDragging ? "Drop your file here" : "Drag & drop your image or video"}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        or click to browse
                      </p>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      JPG, PNG, GIF, WebP, SVG, MP4, WebM, MOV • Max 50MB
                    </p>
                  </div>
                )}

                {/* File Preview */}
                {filePreview && selectedFile && (
                  <div className="space-y-3">
                    <div className="relative rounded-xl overflow-hidden bg-muted border border-border h-48 flex items-center justify-center">
                      {selectedFile.type.startsWith("video/") ? (
                        <video
                          src={filePreview}
                          className="w-full h-full object-cover"
                          controls
                        />
                      ) : (
                        <img
                          src={filePreview}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      )}
                      <button
                        type="button"
                        onClick={handleClearFile}
                        disabled={isLoading}
                        className="absolute top-2 right-2 p-1.5 rounded-lg bg-destructive/90 hover:bg-destructive text-primary-foreground transition-all shadow-lg"
                        title="Remove and upload different file"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground truncate">
                            {selectedFile.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB • {selectedFile.type.split('/')[1].toUpperCase()}
                          </p>
                        </div>
                        <div className="text-xs font-semibold text-primary bg-primary/10 px-2 py-1 rounded">
                          Ready
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={isLoading}
                className="flex-1 rounded-lg"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="flex-1 rounded-lg gap-2"
              >
                {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                {isLoading ? "Adding..." : "Add Jersey"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
