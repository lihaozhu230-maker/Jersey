import { useState } from "react";
import { Jersey } from "@shared/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Edit2, Check, X, Lock } from "lucide-react";
import { toast } from "sonner";
import { LoginDialog } from "@/components/LoginDialog";

interface JerseyCardProps {
  jersey: Jersey;
  onUpdate: (id: string, price: number) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

export function JerseyCard({ jersey, onUpdate, onDelete }: JerseyCardProps) {
  const { isAuthenticated } = useAuth();
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [newPrice, setNewPrice] = useState(jersey.price.toString());
  const [isLoading, setIsLoading] = useState(false);
  const [loginDialogOpen, setLoginDialogOpen] = useState(false);

  const handlePriceUpdate = async () => {
    const price = parseFloat(newPrice);
    if (isNaN(price) || price <= 0) {
      toast.error("Please enter a valid price");
      return;
    }

    setIsLoading(true);
    try {
      await onUpdate(jersey.id, price);
      setIsEditingPrice(false);
      toast.success("Price updated successfully!");
    } catch (error) {
      toast.error("Failed to update price");
      setNewPrice(jersey.price.toString());
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (
      !window.confirm(
        `Are you sure you want to delete "${jersey.name}"? This action cannot be undone.`
      )
    ) {
      return;
    }

    setIsLoading(true);
    try {
      await onDelete(jersey.id);
      toast.success("Jersey deleted successfully!");
    } catch (error) {
      toast.error("Failed to delete jersey");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="group relative h-full rounded-xl overflow-hidden bg-card border border-border shadow-sm hover:shadow-lg transition-all duration-300 hover:border-primary/50">
      {/* Media Container */}
      <div className="relative h-64 overflow-hidden bg-gradient-to-br from-primary/5 to-accent/5">
        {jersey.mediaType === "video" ? (
          <video
            src={jersey.media}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            controls
            poster={undefined}
          />
        ) : (
          <img
            src={jersey.media}
            alt={jersey.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
        )}
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col gap-3">
        {/* Team Name */}
        <div className="text-sm font-semibold text-primary uppercase tracking-wide">
          {jersey.team}
        </div>

        {/* Jersey Name */}
        <h3 className="text-lg font-bold text-foreground line-clamp-2">
          {jersey.name}
        </h3>

        {/* Price Section */}
        <div className="mt-auto pt-3 border-t border-border">
          {isEditingPrice ? (
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <label className="text-xs font-medium text-muted-foreground block mb-1">
                  New Price
                </label>
                <div className="flex items-center gap-1 bg-input rounded-lg px-2 py-1">
                  <span className="text-primary font-semibold">$</span>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="border-0 p-0 h-auto text-base font-semibold focus-visible:ring-0"
                    disabled={isLoading}
                    autoFocus
                  />
                </div>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={handlePriceUpdate}
                  disabled={isLoading}
                  className="p-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
                  title="Save"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    setIsEditingPrice(false);
                    setNewPrice(jersey.price.toString());
                  }}
                  disabled={isLoading}
                  className="p-1.5 rounded-lg bg-muted text-muted-foreground hover:bg-muted/80 transition-colors disabled:opacity-50"
                  title="Cancel"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold text-primary">
                  ${jersey.price.toFixed(2)}
                </span>
              </div>
              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => {
                    if (!isAuthenticated) {
                      setLoginDialogOpen(true);
                    } else {
                      setIsEditingPrice(true);
                    }
                  }}
                  disabled={isLoading}
                  className={`p-2 rounded-lg transition-colors ${
                    isAuthenticated
                      ? "bg-primary/10 text-primary hover:bg-primary/20 disabled:opacity-50"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted/70"
                  }`}
                  title={isAuthenticated ? "Edit price" : "Sign in to edit"}
                >
                  {isAuthenticated ? (
                    <Edit2 className="w-4 h-4" />
                  ) : (
                    <Lock className="w-4 h-4" />
                  )}
                </button>
                <button
                  onClick={() => {
                    if (!isAuthenticated) {
                      setLoginDialogOpen(true);
                    } else {
                      handleDelete();
                    }
                  }}
                  disabled={isLoading}
                  className={`p-2 rounded-lg transition-colors ${
                    isAuthenticated
                      ? "bg-destructive/10 text-destructive hover:bg-destructive/20 disabled:opacity-50"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted/70"
                  }`}
                  title={isAuthenticated ? "Delete jersey" : "Sign in to delete"}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      <LoginDialog
        open={loginDialogOpen}
        onOpenChange={setLoginDialogOpen}
      />
    </div>
  );
}
