import { useEffect, useState } from "react";
import { Jersey, CreateJerseyRequest } from "@shared/api";
import { Header } from "@/components/Header";
import { JerseyCard } from "@/components/JerseyCard";
import { UploadJerseyDialog } from "@/components/UploadJerseyDialog";
import { Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Index() {
  const [jerseys, setJerseys] = useState<Jersey[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch jerseys on mount
  useEffect(() => {
    fetchJerseys();
  }, []);

  const fetchJerseys = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await fetch("/api/jerseys");
      if (!response.ok) throw new Error("Failed to fetch jerseys");
      const data = await response.json();
      setJerseys(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to load jerseys";
      setError(message);
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddJersey = async (jersey: CreateJerseyRequest) => {
    try {
      const response = await fetch("/api/jerseys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(jersey),
      });
      if (!response.ok) throw new Error("Failed to add jersey");
      const newJersey = await response.json();
      setJerseys((prev) => [newJersey, ...prev]);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to add jersey";
      throw new Error(message);
    }
  };

  const handleUpdatePrice = async (id: string, price: number) => {
    try {
      const response = await fetch(`/api/jerseys/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ price }),
      });
      if (!response.ok) throw new Error("Failed to update price");
      const updated = await response.json();
      setJerseys((prev) =>
        prev.map((jersey) => (jersey.id === id ? updated : jersey))
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to update price";
      throw new Error(message);
    }
  };

  const handleDeleteJersey = async (id: string) => {
    try {
      const response = await fetch(`/api/jerseys/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete jersey");
      setJerseys((prev) => prev.filter((jersey) => jersey.id !== id));
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to delete jersey";
      throw new Error(message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex-1 max-w-2xl">
              <div className="inline-block mb-4 px-3 py-1 rounded-full bg-primary/10 border border-primary/20">
                <span className="text-sm font-semibold text-primary">
                  ⚽ Premium Collection
                </span>
              </div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-4 leading-tight">
                Discover Premium
                <br />
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Football Jerseys
                </span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Explore our curated collection of authentic football jerseys. Easily upload new
                jerseys and manage prices in real-time.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <UploadJerseyDialog onAdd={handleAddJersey} />
                <div className="text-sm text-muted-foreground pt-2">
                  <p className="font-semibold text-foreground">
                    {jerseys.length} {jerseys.length === 1 ? "Jersey" : "Jerseys"}
                  </p>
                  <p>in collection</p>
                </div>
              </div>
            </div>

            {/* Decorative Element */}
            <div className="hidden lg:flex flex-1 justify-end">
              <div className="relative w-full max-w-sm aspect-square">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl transform rotate-45"></div>
                <div className="absolute inset-8 bg-gradient-to-tr from-accent/30 to-primary/30 rounded-3xl"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="relative py-12 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Error State */}
          {error && (
            <div className="mb-8 p-4 rounded-xl bg-destructive/10 border border-destructive/20 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-destructive">Error loading jerseys</p>
                <p className="text-sm text-destructive/80 mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-20">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <p className="text-muted-foreground">Loading jerseys...</p>
              </div>
            </div>
          )}

          {/* Empty State */}
          {!isLoading && !error && jerseys.length === 0 && (
            <div className="py-20 text-center">
              <div className="inline-block mb-4 p-3 rounded-full bg-primary/10">
                <svg
                  className="w-8 h-8 text-primary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 13l-7 7-7-7m0 0V6m0 0h12"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">
                No Jerseys Yet
              </h3>
              <p className="text-muted-foreground mb-6">
                Get started by uploading your first football jersey
              </p>
              <UploadJerseyDialog onAdd={handleAddJersey} />
            </div>
          )}

          {/* Jerseys Grid */}
          {!isLoading && jerseys.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {jerseys.map((jersey) => (
                <JerseyCard
                  key={jersey.id}
                  jersey={jersey}
                  onUpdate={handleUpdatePrice}
                  onDelete={handleDeleteJersey}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-1">
              <h3 className="font-bold text-foreground mb-4">Jersey Showcase</h3>
              <p className="text-sm text-muted-foreground">
                Premium football jerseys curated for collectors and fans.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-sm mb-3">
                Features
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Upload Jerseys</li>
                <li>Manage Prices</li>
                <li>Real-time Updates</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-sm mb-3">
                Support
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Documentation</li>
                <li>Help Center</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-sm mb-3">
                Legal
              </h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Privacy</li>
                <li>Terms</li>
                <li>License</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>
              © {new Date().getFullYear()} Jersey Showcase. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
